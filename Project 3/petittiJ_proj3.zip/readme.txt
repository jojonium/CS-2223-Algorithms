Joseph Petitti - Project 3

To run this code, simply run Project_3.py. This will read input from a file called "input.txt," formatted as the instructions show, and calculate the closest distance between two points. The program will print the answer and runtime found from both the recursive algorithm and the brute force algorithm.

To test with different files, run:
Project_3.py <input filename>
Where <input filename> is the name of a correctly formatted text file in the same directory as Project_2.py. Entering the name of a nonexistent file, or not including this argument, will default to "input.txt"